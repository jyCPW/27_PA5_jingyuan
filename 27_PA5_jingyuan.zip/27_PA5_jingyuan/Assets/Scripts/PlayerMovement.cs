﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public float speed;
    Rigidbody PlayerRigidbody;
    public Text RemainCol;
    public GameObject[] Col;
    

    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
        Scene thisScene = SceneManager.GetActiveScene();
        string scenename = thisScene.name;
    }

    // Update is called once per frame
    void Update()
    {
        Col = GameObject.FindGameObjectsWithTag("Wincon");
        RemainCol.text = "Coins left : " + (Col.Length);
        if (RemainCol.text == "Coins left : 0" && SceneManager.GetActiveScene() == SceneManager.GetSceneByName ("GamePlay_Level1"))
        {
            SceneManager.LoadScene("GamePlay_Level2");
        } 
        else if(RemainCol.text == "Coins left : 0" && SceneManager.GetActiveScene() == SceneManager.GetSceneByName("GamePlay_Level2"))
        {
            SceneManager.LoadScene("WinScene");
        }
    }

    void FixedUpdate()
    {
        float Horizontalmove = Input.GetAxis("Horizontal");
        float verticalmove = Input.GetAxis("Vertical");
        Vector3 move = new Vector3(Horizontalmove, 0, verticalmove);
        PlayerRigidbody.AddForce(move * speed * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Wincon")
        {
            Destroy(other.gameObject);
        }

        if (other.tag == "obstacles")
        {
            SceneManager.LoadScene("LoseScene");
        }
    }
}
