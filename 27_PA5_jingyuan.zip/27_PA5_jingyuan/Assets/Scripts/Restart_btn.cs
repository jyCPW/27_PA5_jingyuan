﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Restart_btn : MonoBehaviour
{
    public Button Restart;
    // Start is called before the first frame update
    void Start()
    {
        Button REbtn = Restart.GetComponent<Button>();
        REbtn.onClick.AddListener(Onclick);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Onclick()
    {
        SceneManager.LoadScene("GamePlay_Level1");
    }
}
